# MathType for Word 與 PowerPoint

[English](README.md)

可安裝的 AI Agent skill、Codex/Claude plugin 與 MCP server，用於在 Microsoft Word 與 PowerPoint 建立可編輯的 MathType 7 公式；Word 文件另支援 MathType 原生公式編號與動態交叉引用。

## AI Agent 靜默操作

AI Agent 編輯 Word、PowerPoint 或 MathType 內容時，必須在背景靜默執行：不得顯示或切換至應用程式視窗、搶奪鍵盤焦點、彈出 modal dialog，亦不得以滑鼠或鍵盤自動化操作可見 UI。若某一步驟無法靜默完成，應停止並回報限制，不可接管使用者桌面。

## 功能

- 建立真正可編輯的 `Equation.DSMT4` 物件，不以 Word OMath、圖片或手打 Unicode 公式代替。
- 支援 DOCX 行內公式與置中的獨立公式。
- 掃描完整文章後，自動將原稿中的數學內容分類為行內公式、未編號獨立公式、編號獨立公式或動態引用；唯讀掃描可找出純文字數學（含 Word 上下標格式），標記步驟再把審閱後的片段換成標記。
- 插入 `(1)` 等 Word MathType 原生編號及動態引用。
- 透過隱藏的 Word 轉換文件，在 PowerPoint 建立置中的浮動 MathType 公式。
- 保留來源 Office 檔案並驗證輸出成品。
- 提供 Codex、Claude Code、Claude Desktop 與 ChatGPT Desktop 可使用的跨 Agent skill/plugin；本機 MCP server 可直接供 Codex 與 Claude 使用，ChatGPT 須透過 remote endpoint 或 Secure MCP Tunnel。

## 系統需求

- Windows 10 或 11。
- 支援 COM automation 的 Microsoft Word 與 PowerPoint 桌面版。
- `PATH` 中可使用 Python 3。伺服器只用標準函式庫，不需以 pip 安裝任何套件。
- 可使用 `pwsh.exe` 的 PowerShell 7 以上版本。若尚未安裝，plugin 會為目前使用者安裝 PowerShell 7.6 LTS 並告知，參閱 [PowerShell 7](#powershell-7)。
- 從 [MathType 下載頁面](https://mathtype.tw/download/)安裝桌面版 **MathType for Windows**。

本專案以 **MathType-win-zh-7.11.1.462** 開發與驗證，其 `ProductVersion` 為 `7.11.1.462`。請安裝 **MathType for Windows**，不可只安裝 **MathType Add-In for Microsoft 365**。Microsoft 365 工作窗格外掛不具備本工具使用的桌面 OLE、Word template、PowerPoint add-in 與 COM 工作流。

MathType 與 Microsoft Office 為專有產品，本 repository 不包含其安裝程式或授權。

## 終端機相容性

Office bridge 是 Windows PowerShell 7 腳本。外層終端機可使用 PowerShell 7、Windows 上的 Bash，包括 Git Bash，或 CMD，但實際 bridge process 必須由 `pwsh.exe` 執行。

| 目前終端機 | 執行方式 |
|---|---|
| PowerShell 7+ | 直接以 `pwsh.exe` 執行命令。 |
| Windows 上的 Bash，包括 Git Bash | 呼叫 Windows `pwsh.exe`。 |
| WSL Bash | 呼叫 Windows `pwsh.exe`；Linux `pwsh` 無法執行 Windows Office COM automation。 |
| CMD | 以相同參數呼叫 `pwsh.exe`。 |
| Windows PowerShell 5.1 | 不可直接執行 bridge；切換至 Git Bash 或 CMD，再呼叫 `pwsh.exe`。 |
| 找不到 `pwsh.exe` | 由 MCP server 自動安裝 PowerShell 7，或依下方說明執行 `scripts/ensure-pwsh.ps1`。 |

以下命令可在 PowerShell 7、Git Bash 與 CMD 執行：

```console
pwsh.exe -NoProfile -ExecutionPolicy Bypass -File scripts/mathtype-word.ps1 -Action probe
```

### PowerShell 7

MCP server 是 Python 程式，啟動時不需要 PowerShell 7：plugin 的啟動命令在每台受支援 Windows 皆內建的 Windows PowerShell 5.1（`powershell.exe`）下執行，上方的手動註冊則直接啟動 `python`。bridge 在 PowerShell 7 中執行。系統沒有 PowerShell 7 時，第一個需要它的工具呼叫會為目前使用者安裝 PowerShell 7.6.6（LTS），並告知安裝內容：

- 來源為 GitHub 上官方的 PowerShell ZIP 發行檔；SHA-256 必須與 `scripts/ensure-pwsh.ps1` 內固定的雜湊一致，且 `pwsh.exe` 必須具有效的 Microsoft 簽章，否則拒絕安裝。
- 安裝至 `%USERPROFILE%\.mathtype-for-word\PowerShell\<version>`。不需系統管理員權限、不跳出提示，也不修改 PATH 或登錄；僅供本 plugin 使用，刪除該資料夾即移除。此副本只隨本 plugin 的新版本更新。
- 下載量約 106 MB，安裝後約占 300 MB。安裝期間，工具呼叫會回覆 PowerShell 7 正在安裝及其位置；安裝完成後的下一次呼叫回報安裝內容，再下一次才執行工作。

未使用 MCP 時，可在任何終端機執行同一個安裝程式；它會輸出應使用的 `pwsh.exe` 路徑，下載可能需要數分鐘。`python scripts/mathtype_batch.py render` 在需要時也以相同方式安裝：

```console
powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File scripts/ensure-pwsh.ps1
```

若下載受阻（離線、proxy 或政策限制），請自行安裝 PowerShell 7，例如以 MSI 安裝程式（`winget install --id Microsoft.PowerShell --source winget --installer-type wix`，需系統管理員權限），或參閱 [Microsoft PowerShell 更新常見問題](https://learn.microsoft.com/zh-tw/powershell/scripting/install/microsoft-update-faq?view=powershell-7.6)。

## 透過 AI Agent 安裝

若要在 Claude Code、Claude Desktop、Codex 或 ChatGPT Desktop 使用本工具，貼上以下 prompt，Agent 會依目前環境完成設定：

```text
從 https://github.com/felimet/mathtype-for-word 安裝或升級 MathType for Word and PowerPoint toolkit。偵測我目前可用的終端機，並使用 PowerShell 7、Windows 上的 Bash，包括 Git Bash，或 CMD。不可在 Windows PowerShell 5.1 執行 Office bridge；若目前為 5.1，切換至 Git Bash 或 CMD，再呼叫 Windows pwsh.exe。從 WSL Bash 執行時，呼叫 Windows pwsh.exe，不使用 Linux pwsh。若找不到 pwsh.exe，以 Windows powershell.exe 執行 scripts/ensure-pwsh.ps1，為目前使用者安裝 PowerShell 7，並告訴我安裝了什麼；若安裝失敗，停止執行並提示我依 https://learn.microsoft.com/zh-tw/powershell/scripting/install/microsoft-update-faq?view=powershell-7.6 安裝 PowerShell 7。確認桌面版 MathType for Windows ProductVersion 7.11.1.462，以及 Microsoft Word 與 PowerPoint 桌面版均可使用；安裝可攜式 skill、註冊本機 stdio MCP server、執行兩項 MathType probe 與 repository 測試、保留既有 Agent 設定，並列出所有異動檔案。輸出未包含可編輯 Equation.DSMT4 物件或 validation 未回傳 ok: true 時，不得宣稱完成。
```

再告訴 Agent 要處理的 DOCX 或 PPTX，以及需要建立的公式。

各平台 skill 位置與 MCP 設定見[安裝矩陣](skills/mathtype-for-word/references/installation-matrix.md)。

## 將 Skill 與 MCP 加入各 AI Agent

先將 `<REPO_ROOT>` 換成 repository 的本機絕對路徑。修改設定檔時必須保留原有 MCP 項目。

### Codex

從本 repository 的 marketplace 安裝 plugin。Plugin 內含 skill 與 MCP server，從安裝資料夾啟動 server，設定 1200 秒工具上限，並轉送 `MATHTYPE_*` 設定：

```console
codex plugin marketplace add felimet/mathtype-for-word
codex plugin add mathtype-for-word@mathtype-for-word
```

升級時執行 `codex plugin marketplace upgrade mathtype-for-word`，再執行一次 `codex plugin add`。安裝或升級後重新啟動 Codex。

若要改為手動註冊，將 `skills/mathtype-for-word` 複製至 `%USERPROFILE%\.codex\skills\mathtype-for-word` 或 `%USERPROFILE%\.agents\skills\mathtype-for-word`，再註冊 MCP server：

```console
codex mcp add mathtype-for-word -- python "<REPO_ROOT>\scripts\mcp_server.py"
codex mcp get mathtype-for-word
```

Codex 預設在 300 秒後結束一次工具呼叫，渲染中的單一 Word session 可能更久。請在 `%USERPROFILE%\.codex\config.toml` 的該 server 項目加上與 plugin 相同的上限；需要多個 session 的 manifest 仍應在背景執行（`background: true`）：

```toml
[mcp_servers.mathtype-for-word]
tool_timeout_sec = 1200
```

Codex 只把固定一組環境變數傳給 MCP server。若要調整 `MATHTYPE_OFFICE_TIMEOUT_SECONDS` 或其他 `MATHTYPE_*` 設定，請在同一項目的 `env_vars` 列出變數名稱。

Plugin 與手動註冊擇一使用：以 `codex mcp add` 註冊的同名 server 優先於 plugin 內的 server。Plugin 會轉送 `MATHTYPE_WORD_POWERSHELL`、`MATHTYPE_OFFICE_TIMEOUT_SECONDS`（或其 1.3.0 名稱 `MATHTYPE_WORD_TIMEOUT_SECONDS`）與 `MATHTYPE_BRIDGE_LOCK_WAIT_SECONDS`。

### Claude Code

從本 repository 的 marketplace 安裝 plugin：

```console
claude plugin marketplace add felimet/mathtype-for-word
claude plugin install mathtype-for-word@mathtype-for-word
```

升級時執行 `claude plugin marketplace update mathtype-for-word` 與 `claude plugin update mathtype-for-word@mathtype-for-word`。

若要改為手動註冊，將 `skills/mathtype-for-word` 複製至 `%USERPROFILE%\.claude\skills\mathtype-for-word`，再註冊 MCP server：

```console
claude mcp add --scope user mathtype-for-word -- python "<REPO_ROOT>\scripts\mcp_server.py"
claude mcp get mathtype-for-word
```

Plugin 與手動註冊擇一使用，否則 Claude Code 會載入兩個 server 與兩份 skill。安裝或升級後重新啟動 Claude Code。

### Claude Desktop

於 **Customize > Skills** 上傳 `dist/mathtype-for-word.skill`。再將下列 server 合併至 `%APPDATA%\Claude\claude_desktop_config.json`，不可覆蓋其他既有 server，完成後重新啟動 Claude Desktop：

```json
{
  "mcpServers": {
    "mathtype-for-word": {
      "command": "python",
      "args": ["<REPO_ROOT>\\scripts\\mcp_server.py"]
    }
  }
}
```

參閱 Anthropic 的 [Skill 上傳說明](https://support.claude.com/en/articles/12512180-use-skills-in-claude)與[本機 MCP 設定指南](https://modelcontextprotocol.io/docs/develop/connect-local-servers)。

### ChatGPT Desktop

若帳號或 workspace 提供 **Plugins**，依官方 [ChatGPT plugin 流程](https://help.openai.com/en/articles/20001256)安裝或啟用封裝能力。ChatGPT Desktop 不會自動探索本機 repository。OpenAI 目前的 full MCP 文件適用於 ChatGPT web；除非帳號中確實顯示相同的 developer-mode 介面，不可假設桌面版具備相同能力。

ChatGPT 無法直接連接本專案隨附的本機 stdio MCP 命令；必須建立 remote MCP endpoint 或使用 [Secure MCP Tunnel](https://help.openai.com/en/articles/12584461-developer-mode-and-full-mcp-connectors-in-chatgpt-beta)，並依帳號或 workspace 權限啟用 Developer mode 或 Apps。MathType automation 必須在登入中的互動式 Windows 桌面執行，因此 endpoint 或 tunnel 仍須將工具執行路由回該 Windows 主機。本 repository 目前只提供本機 stdio server。

## 數學字型與符號樣式

同一份文件的公式、行內數學、正文、圖表標題與符號定義須使用一致的符號樣式。

| 數學角色 | 樣式 |
|---|---|
| 純量變數及作為變數的希臘字母 | 斜體 |
| 向量 | 粗體小寫 |
| 矩陣與張量 | 粗體大寫 |
| 函數名稱、運算子、縮寫及描述性標籤 | 正體 Roman |
| 數學常數、微分符號及 SI 單位 | 正體 Roman |
| 數值上下標 | 正體；代表變數的索引維持斜體 |

使用 MathType 樣式或 MathML `mathvariant` 表達數學語意，不可以 Unicode 外觀字元模擬粗體或斜體。除非期刊或使用者另有指定，保留文件既有的數學字型家族。IEEE 要求變數在正文與公式中均維持斜體、向量使用粗體、函數使用正體。詳見 [IEEE Mathematics Style Guide](https://journals.ieeeauthorcenter.ieee.org/wp-content/uploads/sites/7/Editing-Mathematics.pdf)及 [IEEE Math Typesetting Guide](https://journals.ieeeauthorcenter.ieee.org/wp-content/uploads/sites/7/IEEE-Math-Typesetting-Guide-for-LaTeX-Users.pdf)。

雙語公式引導、符號定義及完整排版規則見[學術公式樣式參考](skills/mathtype-for-word/references/academic-equation-style.md)。

## 支援格式

| 格式 | MathType 成品 | 編號與引用 |
|---|---|---|
| Word `.docx` | 行內或置中的獨立 `Equation.DSMT4` OLE | MathType 原生編號與動態引用 |
| PowerPoint `.pptx` | 直接在 PowerPoint 建立的置中浮動 `Equation.DSMT4` OLE | PowerPoint 不具備 Word 的 MathType 編號引用機制，本工具不以手打內容假冒 |

PowerPoint 轉換會保持 Word、PowerPoint 與 MathType 隱藏，不使用滑鼠、鍵盤、焦點、`AppActivate` 或 `SendKeys`；轉移已轉換的 OLE 物件時會短暫使用 Windows 剪貼簿，並覆蓋使用者原本複製的內容。

## 驗證安裝

```console
pwsh.exe -NoProfile -ExecutionPolicy Bypass -File scripts/mathtype-word.ps1 -Action probe
pwsh.exe -NoProfile -ExecutionPolicy Bypass -File scripts/mathtype-word.ps1 -Action probe-pptx
pwsh.exe -NoProfile -ExecutionPolicy Bypass -File tests/run-tests.ps1 -IncludeLiveOffice
```

### AI Agent 簡易測試 Prompt

安裝完成後，將下列 Prompt 直接貼給 AI Agent：

```text
請使用已安裝的 MathType for Word and PowerPoint toolkit 進行簡易測試。先執行 Word 與 PowerPoint 的 prerequisite probe，再使用 evals/fixtures/en-paper-draft.docx 搭配 en-word-manifest.json，以及 evals/fixtures/en-presentation-draft.pptx 搭配 en-powerpoint-manifest.json，分別建立新的暫存 DOCX 與 PPTX 輸出。全程保持 Word、PowerPoint 與 MathType 靜默且隱藏，不得覆寫來源 fixture。完成後驗證兩個輸出，回報輸出路徑、MathType 物件數量、Word 原生編號與引用數量，以及 PowerPoint 的 mathml_verified 數量。兩項 validation 未同時回傳 ok: true 時，不得宣稱測試成功。
```

Bridge 會保留來源檔，先驗證同層暫存 Office 檔，再以原子方式發布；除非明確指定 `-Overwrite`，否則不覆寫既有輸出。所有可處理的結束路徑都會刪除帶有本次執行 token 的暫存 sibling，並只掃除命名格式完全相符且超過 24 小時的舊檔；MCP 逾時也會使用相同 token 要求清理。

大型 Word 文件會分批在全新的 Word 工作階段中渲染（`batch_size`，預設 40），可中斷續跑，也可在背景執行並以 `get_mathtype_render_status` 查詢進度；整份清單嚴格驗證通過後才發布輸出。同一時間只執行一個渲染工作。逾時時只終止 bridge 記錄為自身啟動的 Office 程序；PowerPoint 作業不會關閉使用者原本已開啟的 PowerPoint。

## Repository 結構

| 路徑 | 用途 |
|---|---|
| `skills/mathtype-for-word/` | 跨 Agent skill、參考資料及 launcher |
| `scripts/` | Office automation bridge、MCP server 及封裝程式 |
| `config/defaults.json` | Word 公式編號預設設定 |
| `evals/fixtures/` | 真實繁中、英文 DOCX/PPTX 評測輸入 |
| `tests/` | 靜態、MCP、Office 整合、視覺與封裝測試 |
| `CHANGELOG.md` | 各版本變更紀錄 |

## 封裝

```console
python scripts/package_plugin.py
```

命令會產生 `dist/mathtype-for-word-plugin.zip` 及 SHA-256 檔。獨立 skill 套件為 `dist/mathtype-for-word.skill`。

## 問題回報與交流

若有任何問題，請至 [GitHub Issues](https://github.com/felimet/mathtype-for-word/issues) 提出並交流。

## 授權

[MIT](LICENSE)
